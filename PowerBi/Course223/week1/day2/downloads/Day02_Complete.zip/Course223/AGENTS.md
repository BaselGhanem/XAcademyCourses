# Course223 authoring rules

- Keep instructor-only content out of learner-facing pages and downloads: trainer scripts, internal timelines, answer keys, expected outputs, validation tools, and instructor bundles belong in Trainer.
- Apply this separation to every new learner experience. The user explicitly requested this as an ongoing design preference on 2026-10-17.
- Learner resources for Day 2 are the two dirty CSV datasets only. Keep on-page instructions brief and avoid exposing solution totals.
- Put all instructor resources on the trainer page with explicit time slots, speech, screen actions, learner practice, and checks. Preserve local checklist/notes storage.
- Preserve completed Day 1 content, source demos, recording, login and day gating.
- Modify only PowerBi/Course223.
- Explicitly mark new learner resources with audience: learner. For days 2 onward, undeclared resources are excluded from learner surfaces. Mark answer/reference CSVs as trainer-only.
