COURSE224 — DAY 10 CAPSTONE
Unzip the whole project. Open Nova.pbip using current Power BI Desktop.
The model is a copy of the validated Stage3 Day07 PBIP source. No new data source was invented.
The instructional page is a STARTING POINT, not a finished report.
Keep Report and SemanticModel folders together. Refresh and test measures/relationships.
Power BI Desktop Save As PBIX is required for a final runnable learner handoff.
