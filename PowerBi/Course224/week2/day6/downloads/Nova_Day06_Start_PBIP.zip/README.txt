Open Nova.pbip in current Power BI Desktop, Refresh, validate source counts and relationships, then Save As PBIX. This source project was statically validated only.
